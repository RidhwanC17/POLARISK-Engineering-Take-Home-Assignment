"""Deterministic structuring detector.

No LLM, no network, no randomness. `detect_structuring` is a pure function:
same transactions + same config -> same flags, regardless of input order.

Rule (from config.json):
  An account is flagged when it has >= min_transaction_count CREDIT transactions,
  each individually BELOW reporting_threshold, that all fall within one rolling
  window of rolling_window_hours, and whose amounts sum to MORE than
  reporting_threshold.

Boundary conventions (the spec is silent; these are explicit choices, each covered by a test):
  * amount == threshold         -> NOT "below the threshold": excluded from evidence.
  * sum    == threshold         -> NOT "more than the threshold": not flagged.
  * gap    == window length     -> INSIDE the window (inclusive: last - first <= window).
  * count  == min count         -> enough (>=).
"""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

PATTERN = "structuring"


# ----------------------------------------------------------------------------- data types
@dataclass(frozen=True)
class Config:
    reporting_threshold: Decimal
    rolling_window_hours: Decimal
    min_transaction_count: int

    @classmethod
    def from_dict(cls, raw: dict) -> "Config":
        try:
            threshold = Decimal(str(raw["reporting_threshold"]))
            hours = Decimal(str(raw["rolling_window_hours"]))
            raw_count = raw["min_transaction_count"]
            count_decimal = Decimal(str(raw_count))
            if not count_decimal.is_finite() or count_decimal != count_decimal.to_integral_value():
                raise ValueError("min_transaction_count must be a whole number")
            cfg = cls(threshold, hours, int(count_decimal))
        except KeyError as e:
            raise ValueError(f"config is missing required key {e}") from None
        except (InvalidOperation, ValueError, TypeError) as e:
            raise ValueError(f"config has an invalid numeric value: {e}") from None
        if (not cfg.reporting_threshold.is_finite() or not cfg.rolling_window_hours.is_finite()
                or cfg.reporting_threshold <= 0 or cfg.rolling_window_hours <= 0
                or cfg.min_transaction_count < 1):
            raise ValueError("reporting_threshold and rolling_window_hours must be finite and positive; min_transaction_count must be a positive whole number")
        return cfg

    @property
    def window(self) -> timedelta:
        return timedelta(hours=float(self.rolling_window_hours))

    def to_dict(self) -> dict:
        return {
            "reporting_threshold": str(self.reporting_threshold),
            "rolling_window_hours": str(self.rolling_window_hours),
            "min_transaction_count": self.min_transaction_count,
        }


@dataclass(frozen=True)
class Transaction:
    txn_id: str
    account_id: str
    counterparty: str
    amount: Decimal
    direction: str  # "credit" | "debit"
    timestamp: datetime
    channel: str

    def to_dict(self) -> dict:
        return {
            "txn_id": self.txn_id,
            "timestamp": self.timestamp.isoformat(),
            "amount": str(self.amount),
            "direction": self.direction,
            "channel": self.channel,
            "counterparty": self.counterparty,
        }


@dataclass(frozen=True)
class EvidenceWindow:
    transactions: tuple  # tuple[Transaction, ...], ordered by (timestamp, txn_id)
    total: Decimal
    severity_score: int  # deterministic 1-100 heuristic; not a probability

    @property
    def window_start(self) -> datetime:
        return self.transactions[0].timestamp

    @property
    def window_end(self) -> datetime:
        return self.transactions[-1].timestamp

    @property
    def span_hours(self) -> float:
        return round((self.window_end - self.window_start).total_seconds() / 3600, 2)

    def to_dict(self) -> dict:
        return {
            "transaction_count": len(self.transactions),
            "total": str(self.total),
            "window_start": self.window_start.isoformat(),
            "window_end": self.window_end.isoformat(),
            "span_hours": self.span_hours,
            "severity_score": self.severity_score,
            "transactions": [t.to_dict() for t in self.transactions],
        }


@dataclass(frozen=True)
class Flag:
    account_id: str
    windows: tuple  # tuple[EvidenceWindow, ...]; non-overlapping, chronological
    pattern: str = PATTERN

    @property
    def severity_score(self) -> int:
        """Account-level score is the strongest (maximum) evidence-window score."""
        return max(w.severity_score for w in self.windows)

    def to_dict(self) -> dict:
        return {
            "account_id": self.account_id,
            "pattern": self.pattern,
            "severity_score": self.severity_score,
            "evidence_windows": [w.to_dict() for w in self.windows],
        }


# ----------------------------------------------------------------------------- loading (I/O lives here, not in the detector)
def load_config(path) -> Config:
    # parse_float=Decimal so e.g. 49999.99 is never routed through binary floating point
    with open(path, encoding="utf-8") as f:
        return Config.from_dict(json.load(f, parse_float=Decimal))


def load_transactions(path) -> list:
    """Parse the CSV strictly. Any malformed row raises ValueError naming the row,
    rather than being silently skipped (a skipped row could hide a structuring pattern)."""
    required = {"txn_id", "account_id", "counterparty", "amount", "direction", "timestamp", "channel"}
    txns, seen = [], set()
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"CSV is missing columns: {sorted(missing)}")
        for n, row in enumerate(reader, start=2):  # row 1 is the header
            try:
                if None in row:
                    raise ValueError("row contains more values than the CSV header")
                if any(row.get(name) is None for name in required):
                    raise ValueError("row has a missing required field")
                amount = Decimal(row["amount"].strip())  # Decimal from the text, never via float
                if not amount.is_finite() or amount <= 0:
                    raise ValueError(f"amount must be a positive number, got {row['amount']!r}")
                direction = row["direction"].strip().lower()
                if direction not in ("credit", "debit"):
                    raise ValueError(f"direction must be credit/debit, got {row['direction']!r}")
                txn = Transaction(
                    txn_id=row["txn_id"].strip(),
                    account_id=row["account_id"].strip(),
                    counterparty=row["counterparty"].strip(),
                    amount=amount,
                    direction=direction,
                    timestamp=datetime.fromisoformat(row["timestamp"].strip()),
                    channel=row["channel"].strip(),
                )
                if not txn.txn_id or not txn.account_id:
                    raise ValueError("txn_id and account_id must be non-empty")
                if txn.txn_id in seen:
                    raise ValueError(f"duplicate txn_id {txn.txn_id!r} (would be double-counted)")
            except (InvalidOperation, ValueError, TypeError, AttributeError) as e:
                raise ValueError(f"{path}, row {n}: {e}") from None
            seen.add(txn.txn_id)
            txns.append(txn)
    # Mixing naive and timezone-aware timestamps makes window arithmetic meaningless.
    if len({t.timestamp.tzinfo is None for t in txns}) > 1:
        raise ValueError("timestamps mix timezone-aware and naive values; normalise them first")
    return txns




def _severity_score(transactions: tuple, total: Decimal, cfg: Config) -> int:
    """Return a deterministic 1-100 severity heuristic for one qualifying window.

    40%: threshold exceedance, capped when the total is 2x the threshold.
    30%: transaction-count excess, capped at 2x the minimum count.
    30%: temporal concentration, where a shorter qualifying span scores higher.

    This is a transparent ranking aid, NOT a probability of fraud or a calibrated
    risk estimate. The +1 ensures every qualifying window receives at least 1.
    """
    count = len(transactions)
    threshold_excess = min((total - cfg.reporting_threshold) / cfg.reporting_threshold, Decimal(1))
    count_excess = min(
        Decimal(count - cfg.min_transaction_count) / Decimal(cfg.min_transaction_count),
        Decimal(1),
    )
    span = transactions[-1].timestamp - transactions[0].timestamp
    span_seconds = (
        Decimal(span.days * 86400 + span.seconds)
        + Decimal(span.microseconds) / Decimal(1_000_000)
    )
    window_seconds = cfg.rolling_window_hours * Decimal(3600)
    compactness = max(Decimal(0), Decimal(1) - span_seconds / window_seconds)
    raw = (
        Decimal("0.40") * threshold_excess
        + Decimal("0.30") * count_excess
        + Decimal("0.30") * compactness
    )
    return 1 + int((raw * Decimal(99)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


# ----------------------------------------------------------------------------- the detector
def _eligible(t: Transaction, cfg: Config) -> bool:
    """Only credits strictly below the threshold can be structuring evidence."""
    return t.direction == "credit" and t.amount < cfg.reporting_threshold


def _find_windows(txns: list, cfg: Config) -> list:
    """txns: one account's eligible credits, sorted by (timestamp, txn_id).

    Anchor a window at each transaction in turn and take EVERY transaction within `window`
    of that anchor (inclusive). Because all amounts are positive, the anchored window is a
    superset of any other window that starts at the same transaction, so if *any* qualifying
    window exists, an anchored one does too. After a hit, resume after the window so evidence
    windows never overlap and each is a genuine <= window-length span.
    Two pointers + prefix sums: O(n) per account after the O(n log n) sort.
    """
    window, found, n = cfg.window, [], len(txns)
    prefix = [Decimal(0)]  # prefix[k] = sum of the first k amounts, exact (Decimal)
    for t in txns:
        prefix.append(prefix[-1] + t.amount)
    i = j = 0
    while i < n:
        j = max(j, i)  # j (window end) never moves backwards because timestamps are sorted
        while j + 1 < n and txns[j + 1].timestamp - txns[i].timestamp <= window:
            j += 1
        count, total = j - i + 1, prefix[j + 1] - prefix[i]
        if count >= cfg.min_transaction_count and total > cfg.reporting_threshold:
            evidence = tuple(txns[i : j + 1])
            found.append(EvidenceWindow(
                transactions=evidence,
                total=total,
                severity_score=_severity_score(evidence, total, cfg),
            ))
            i = j + 1
        else:
            i += 1
    return found


def detect_structuring(transactions, config: Config) -> list:
    """Pure function. Returns flagged accounts, sorted by account_id, with exact evidence."""
    by_account = defaultdict(list)
    for t in transactions:
        if _eligible(t, config):
            by_account[t.account_id].append(t)

    flags = []
    for account_id in sorted(by_account):
        ordered = sorted(by_account[account_id], key=lambda t: (t.timestamp, t.txn_id))
        windows = _find_windows(ordered, config)
        if windows:
            flags.append(Flag(account_id=account_id, windows=tuple(windows)))
    return flags
