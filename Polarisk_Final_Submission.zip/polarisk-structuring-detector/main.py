"""CLI: CSV + config in, JSON out.   python main.py [--no-llm]"""
import argparse
import json
import math
import sys

from detector import detect_structuring, load_config, load_transactions
from explainer import LLMClient, LLMError, explain_flags


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Detect structuring and (optionally) explain each flag with an LLM.")
    p.add_argument("--transactions", default="transactions.csv")
    p.add_argument("--config", default="config.json")
    p.add_argument("--out", default="flags.json")
    p.add_argument("--no-llm", action="store_true", help="deterministic detection only; no narratives")
    p.add_argument("--delay", type=float, default=2.5, help="seconds between LLM calls (default 2.5, ~24/min)")
    args = p.parse_args(argv)
    if not math.isfinite(args.delay) or args.delay < 0:
        p.error("--delay must be a finite, non-negative number")

    config = load_config(args.config)
    txns = load_transactions(args.transactions)

    # Step 1: deterministic. This result is final; nothing below can change it.
    flags = detect_structuring(txns, config)
    print(f"{len(txns)} transactions, {len(flags)} accounts flagged: {', '.join(f.account_id for f in flags) or '-'}")
    for f in flags:
        print(f"  {f.account_id}: severity score {f.severity_score}/100")

    # Step 2: narration only.
    narratives = {}
    if not args.no_llm and flags:
        try:
            client = LLMClient()
            print(f"Calling {client.model} once per flagged account ({len(flags)} calls)...")
            narratives = explain_flags(flags, config, client, delay_seconds=args.delay)
        except LLMError as e:
            # Detection is already complete. Missing credentials/configuration for the
            # optional explainer must not prevent the authoritative flags from being saved.
            print(f"[explainer] unavailable: {e}", file=sys.stderr)
            narratives = {
                f.account_id: {"narrative": None, "error": f"LLM unavailable: {e}"}
                for f in flags
            }

    out = {"config": config.to_dict(), "flagged_accounts": []}
    for f in flags:
        entry = f.to_dict()
        if not args.no_llm:
            entry["narrative"] = narratives.get(f.account_id, {}).get("narrative")
            entry["narrative_error"] = narratives.get(f.account_id, {}).get("error")
        out["flagged_accounts"].append(entry)

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
    print(f"Wrote {args.out}")
    for e in out["flagged_accounts"]:
        if e.get("narrative"):
            print(f"\n{e['account_id']}: {e['narrative']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
