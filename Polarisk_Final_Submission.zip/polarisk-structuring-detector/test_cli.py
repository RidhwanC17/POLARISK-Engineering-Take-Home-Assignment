import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[0]


class TestCLI(unittest.TestCase):
    def test_missing_llm_key_still_writes_deterministic_flags(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "flags.json"
            env = os.environ.copy()
            for key in ("GROQ_API_KEY", "LLM_API_KEY", "LLM_BASE_URL", "LLM_MODEL"):
                env.pop(key, None)
            result = subprocess.run(
                [sys.executable, str(ROOT / "main.py"),
                 "--transactions", str(ROOT / "transactions.csv"),
                 "--config", str(ROOT / "config.json"), "--out", str(output)],
                cwd=ROOT, env=env, text=True, capture_output=True, timeout=20,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(output.exists())
            data = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(len(data["flagged_accounts"]), 6)
            self.assertTrue(all(1 <= x["severity_score"] <= 100 for x in data["flagged_accounts"]))
            self.assertTrue(all(x["narrative"] is None for x in data["flagged_accounts"]))
            self.assertTrue(all(x["narrative_error"].startswith("LLM unavailable:")
                                for x in data["flagged_accounts"]))

    def test_negative_delay_is_rejected(self):
        result = subprocess.run(
            [sys.executable, str(ROOT / "main.py"), "--no-llm", "--delay", "-1"],
            cwd=ROOT, text=True, capture_output=True, timeout=10,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("finite, non-negative", result.stderr)


if __name__ == "__main__":
    unittest.main()
