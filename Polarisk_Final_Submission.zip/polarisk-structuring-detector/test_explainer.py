import json
import os
import unittest
from datetime import datetime, timedelta
from decimal import Decimal

from detector import Config, Transaction, detect_structuring  # noqa: E402
from explainer import (DEFAULT_MODEL, GROQ_BASE_URL, LLMClient, LLMError, RateLimited,
                      build_facts, build_messages, explain_flags)  # noqa: E402

CFG = Config(Decimal("50000"), Decimal("72"), 3)
T0 = datetime(2026, 1, 1, 8, 0)


def tx(i, amount, hours, account="A", direction="credit"):
    return Transaction(f"T{i}", account, "SECRET-CP", Decimal(str(amount)), direction, T0 + timedelta(hours=hours), "UPI")


TXNS = [tx(1, 85000, 0), tx(2, 20000, 1), tx(3, 20000, 2), tx(4, 20000, 3),   # T1 is >= threshold: not evidence
        tx(5, 999, 4, "OTHER"), tx(6, 5000, 5, direction="debit")]


class FakeClient:
    def __init__(self, exc=None):
        self.calls, self.exc = 0, exc

    def chat(self, messages):
        self.calls += 1
        if self.exc:
            raise self.exc
        return "narrative"


class TestExplainer(unittest.TestCase):
    def test_client_uses_groq_endpoint_and_default_model(self):
        from unittest.mock import patch
        with patch.dict(os.environ, {"GROQ_API_KEY": "test-key"}, clear=True):
            client = LLMClient()
        self.assertEqual(client.base_url, GROQ_BASE_URL)
        self.assertEqual(client.base_url, "https://api.groq.com/openai/v1")
        self.assertEqual(client.model, DEFAULT_MODEL)

    def test_prompt_contains_only_detector_evidence(self):
        flag = detect_structuring(TXNS, CFG)[0]
        facts = build_facts(flag, CFG)
        ids = {t["txn_id"] for w in facts["evidence_windows"] for t in w["transactions"]}
        self.assertEqual(ids, {"T2", "T3", "T4"})
        user_msg = build_messages(flag, CFG)[1]["content"]
        # T1 (>= threshold), T5 (other account), T6 (debit), counterparty names: none may leak into the prompt
        for excluded in ('"T1"', '"T5"', '"T6"', "OTHER", "SECRET-CP", "85000"):
            self.assertNotIn(excluded, user_msg)

    def test_prompt_does_not_ask_the_model_to_decide(self):
        text = json.dumps(build_messages(detect_structuring(TXNS, CFG)[0], CFG)).lower()
        self.assertNotIn("is this structuring", text)
        self.assertIn("not yours to question or recompute", text)

    def test_rate_limit_stops_further_calls_and_keeps_going_without_crashing(self):
        flags = detect_structuring(TXNS + [tx(10, 20000, 1, "B"), tx(11, 20000, 2, "B"), tx(12, 20000, 3, "B")], CFG)
        self.assertEqual(len(flags), 2)
        client = FakeClient(RateLimited("429"))
        out = explain_flags(flags, CFG, client, delay_seconds=0)
        self.assertEqual(client.calls, 1)                      # no retry loop, no further calls
        self.assertTrue(all(v["narrative"] is None for v in out.values()))

    def test_llm_error_on_one_account_does_not_crash(self):
        out = explain_flags(detect_structuring(TXNS, CFG), CFG, FakeClient(LLMError("boom")), delay_seconds=0)
        self.assertEqual(out["A"]["error"], "boom")


if __name__ == "__main__":
    unittest.main()
