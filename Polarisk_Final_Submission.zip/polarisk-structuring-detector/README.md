# Transaction Pattern Detector (Structuring)

A small command-line service with two deliberately separate stages:

1. **`detector.py` — deterministic detection and severity.** Reads transactions and configuration, identifies accounts meeting the configured structuring rule, and returns exact evidence plus a deterministic 1–100 severity score.
2. **`explainer.py` — Groq-assisted explanation.** Receives only evidence already computed by the detector and generates one analyst-readable paragraph. It never receives the raw transaction list and never makes or changes a flag or severity decision.

The project uses only the Python standard library (Python 3.9+). No package installation is required.

## Run the project (step by step)

### Before you start

- Install Python **3.9 or newer**.
- Extract the ZIP file completely. Do not run the project from inside the ZIP preview.
- Open PowerShell / Terminal in the extracted `polarisk-structuring-detector` folder — the folder that contains `main.py`, `detector.py`, and `transactions.csv`.
- All commands below must be run from that folder. The project uses only the Python standard library, so no `pip install` command is needed.

Check that Python is available:

Windows PowerShell or Command Prompt:

```powershell
python --version
```

If `python` is not recognised on Windows, try:

```powershell
py --version
```

macOS/Linux:

```bash
python3 --version
```

The version should be Python 3.9 or newer.

### 1. Run the tests (recommended first step)

Windows (PowerShell or Command Prompt):

```powershell
python -m unittest discover -v
```

If your Windows installation uses the `py` launcher instead:

```powershell
py -m unittest discover -v
```

macOS/Linux:

```bash
python3 -m unittest discover -v
```

The test files (`test_detector.py`, `test_explainer.py`, and `test_cli.py`) are kept in the project root beside `main.py`; therefore, use the command above from this folder. You do **not** need a separate `tests/` directory. The tests do not call the live Groq API and do not require an API key. A successful run ends with `Ran 16 tests` and `OK`.

### 2. Run deterministic detection only (no API key required)

Windows:

```powershell
python main.py --no-llm --out flags_deterministic.json
```

macOS/Linux:

```bash
python3 main.py --no-llm --out flags_deterministic.json
```

This runs the authoritative detector and writes the results to `flags_deterministic.json`. It does not call Groq and does not require an API key. With the supplied dataset, it should report six flagged accounts: `ACC-1001` through `ACC-1006`.

### 3. Run detection plus Groq explanations (optional)

The Groq explanation step is optional. Detection and severity are completed by deterministic code before the LLM is called. The LLM only writes explanations for already-flagged accounts.

1. Create an account at [console.groq.com](https://console.groq.com/).
2. Create an API key at [console.groq.com/keys](https://console.groq.com/keys/).
3. Set the key in your terminal session. Replace the placeholder with your own key; do not include the key in this ZIP, source files, screenshots, or Git commits.

Windows PowerShell:

```powershell
$env:GROQ_API_KEY="paste-your-key-here"
python main.py --out flags_with_groq.json
```

Windows Command Prompt (CMD):

```bat
set GROQ_API_KEY=paste-your-key-here
python main.py --out flags_with_groq.json
```

macOS/Linux (Bash or Zsh):

```bash
export GROQ_API_KEY="paste-your-key-here"
python3 main.py --out flags_with_groq.json
```

Default model: `openai/gpt-oss-20b`. To select another model available to your Groq account, set `GROQ_MODEL` in the same terminal session before running the command.

The program makes one Groq request per flagged account, sequentially, with a default 2.5-second pause between calls. It does not retry HTTP 429 rate-limit responses.

**Failure isolation:** if the API key is missing or Groq is unavailable, deterministic flags and severity scores are still written to the requested output JSON file. The corresponding `narrative` is `null` and `narrative_error` records the issue. The detection result is never discarded.

### Output files

The output JSON is written to the project folder unless you provide a different path with `--out`. For example, `flags_deterministic.json` and `flags_with_groq.json` are generated outputs; they are not required to run the tests. You can delete them and regenerate them whenever needed.

## Detection rule and explicit boundary conventions

For one account, a qualifying evidence window must contain at least `min_transaction_count` credit transactions, each with a positive amount strictly below `reporting_threshold`, whose timestamps span no more than `rolling_window_hours`, and whose sum is strictly greater than `reporting_threshold`.

| Case | Behaviour |
|---|---|
| Individual amount = threshold | Excluded; it is not below threshold |
| Aggregate sum = threshold | Not flagged; it does not exceed threshold |
| First-to-last timestamp gap = window | Included (inclusive boundary) |
| Count = minimum count | Sufficient |
| Debit transaction | Excluded; this assignment defines deposits/credits |
| Different accounts | Never aggregated together |
| Counterparty/channel | Not used as detection conditions; not specified by the rule |
| Money | `Decimal` arithmetic; no binary floating-point summation |
| Duplicate transaction ID | Input rejected to avoid accidental double-counting |
| Malformed row / missing required column | Input rejected with row context |
| Mixed naive and timezone-aware timestamps | Input rejected; timestamps must use one consistent convention |

## Design note

The required short design note and deliberate edge-case rationale are provided in `DESIGN_NOTE.md`. The alternative considered and rejected is documented in `DECISIONS.md`.

## Deterministic severity score

The score is calculated only after a window qualifies. It is not an ML prediction, confidence probability, or proof of wrongdoing.

For each evidence window:
- `E = min((total - threshold) / threshold, 1)` measures threshold exceedance.
- `C = min((transaction_count - minimum_count) / minimum_count, 1)` measures count above the minimum.
- `K = max(0, 1 - span / configured_window)` rewards tighter time concentration.

`severity_score = 1 + round_half_up(99 * (0.40*E + 0.30*C + 0.30*K))`.

The score is between 1 and 100. For accounts with multiple evidence windows, the account score is the maximum window score. The weights are an explicit heuristic for prioritising review, not statistically calibrated probabilities. Both account and per-window scores are included in `flags.json`.

## Algorithm and complexity

Transactions are grouped by account and eligible credits are sorted by `(timestamp, txn_id)`. A two-pointer rolling-window scan and prefix sums then find qualifying non-overlapping evidence windows.

For an account with `m` eligible credits, sorting costs `O(m log m)` and the scan costs `O(m)`. Across accounts, total sorting cost is `O(sum(m_a log m_a))`. The non-overlapping evidence policy is documented in `DECISIONS.md`; it avoids merging separate episodes into windows longer than the configured duration.

## Result on the supplied data

The nine focused detector tests verify a valid pattern, the exact 72-hour inclusive boundary and a 72-hour-plus-one-minute near-miss, strict individual and aggregate threshold conditions, minimum count, debit filtering, severity calculation, and the supplied CSV. The CSV test confirms six flagged accounts (`ACC-1001` through `ACC-1006`), rejects five deliberate near-misses, and checks that the 85,000 credit in `ACC-1004` is excluded from qualifying evidence.

## Files

- `main.py` — command-line entry point and orchestration.
- `detector.py` — configuration/data loading, deterministic detection, and severity scoring.
- `explainer.py` — facts-only prompt construction and Groq API client.
- `config.json` — configurable threshold, rolling window, and minimum count.
- `transactions.csv` — supplied synthetic dataset.
- `test_detector.py`, `test_explainer.py`, `test_cli.py` — nine focused detector tests plus explainer and CLI tests.
- `DESIGN_NOTE.md` — required half-page explanation of the deterministic/LLM boundary and rejected alternative.
- `DECISIONS.md` — required implementation decisions and AI-assistance record.
