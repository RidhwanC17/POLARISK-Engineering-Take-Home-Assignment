"""Focused deterministic tests for the structuring detection rule.

These nine tests cover a valid pattern, strict amount/count conditions,
rolling-window boundaries, direction filtering, severity, and the supplied CSV.
"""
import os
import unittest
from datetime import datetime, timedelta
from decimal import Decimal

from detector import Config, Transaction, detect_structuring, load_config, load_transactions  # noqa: E402

CFG = Config(Decimal("50000"), Decimal("72"), 3)
T0 = datetime(2026, 1, 1, 8, 0)
_n = [0]


def tx(amount, hours=0.0, account="A", direction="credit", minutes=0):
    _n[0] += 1
    return Transaction(
        f"T{_n[0]}", account, "CP", Decimal(str(amount)), direction,
        T0 + timedelta(hours=hours, minutes=minutes), "UPI"
    )


def flagged(txns, cfg=CFG):
    return [f.account_id for f in detect_structuring(txns, cfg)]


class TestStructuring(unittest.TestCase):
    def test_valid_structuring_pattern_returns_exact_evidence(self):
        flags = detect_structuring(
            [tx(14800, 0), tx(13200, 3), tx(12900, 6), tx(11600, 9)], CFG
        )
        self.assertEqual(len(flags), 1)
        window = flags[0].windows[0]
        self.assertEqual(window.total, Decimal("52500"))
        self.assertEqual(len(window.transactions), 4)
        self.assertEqual(window.span_hours, 9.0)

    def test_edge_exactly_72_hours_is_included(self):
        # DELIBERATE EDGE CASE: the rolling-window boundary (see DESIGN_NOTE.md).
        # Why this case: the spec says "within a rolling window" but not whether a gap of exactly
        # 72 hours is inside it, so this is where an off-by-one (< vs <=) would hide. The supplied
        # near-miss ACC-2002 is 72h01m, so the next test covers the other side of the same boundary.
        # Decision: the boundary is inclusive, so a span of exactly 72 hours qualifies.
        self.assertEqual(flagged([tx(20000, 0), tx(20000, 36), tx(20000, 72)]), ["A"])

    def test_72_hours_and_one_minute_is_excluded(self):
        # No qualifying 72-hour subset exists, even though the full set totals over 50,000.
        txns = [tx(14000, 0), tx(13500, 30), tx(13200, 54), tx(14200, 72, minutes=1)]
        self.assertEqual(flagged(txns), [])

    def test_individual_credit_equal_to_threshold_is_excluded(self):
        # Each transaction must be strictly below 50,000, not equal to it.
        self.assertEqual(flagged([tx(50000, 0), tx(50000, 5), tx(50000, 10)]), [])

    def test_aggregate_must_be_strictly_greater_than_threshold(self):
        exactly_at_threshold = [tx(20000, 0), tx(20000, 1), tx(10000, 2)]
        one_cent_over = [tx(20000, 0), tx(20000, 1), tx("10000.01", 2)]
        self.assertEqual(flagged(exactly_at_threshold), [])
        self.assertEqual(flagged(one_cent_over), ["A"])

    def test_minimum_transaction_count_is_enforced(self):
        # Two credits total 55,000, but the configured minimum is three.
        self.assertEqual(flagged([tx(28000, 0), tx(27000, 4)]), [])

    def test_debit_only_activity_is_not_flagged(self):
        txns = [tx(20000, 0, direction="debit"), tx(20000, 1, direction="debit"),
                tx(20000, 2, direction="debit")]
        self.assertEqual(flagged(txns), [])

    def test_severity_score_matches_formula_and_is_serialised(self):
        # Four credits total 80,000 over 36h: E=.6, C=1/3, K=.5; score=50.
        flags = detect_structuring(
            [tx(20000, 0), tx(20000, 12), tx(20000, 24), tx(20000, 36)], CFG
        )
        self.assertEqual(flags[0].windows[0].severity_score, 50)
        self.assertEqual(flags[0].severity_score, 50)
        self.assertEqual(flags[0].to_dict()["severity_score"], 50)

    def test_supplied_csv_flags_expected_accounts_and_rejects_near_misses(self):
        root = os.path.dirname(os.path.abspath(__file__))
        cfg = load_config(os.path.join(root, "config.json"))
        txns = load_transactions(os.path.join(root, "transactions.csv"))
        flags = detect_structuring(txns, cfg)
        self.assertEqual([f.account_id for f in flags], [f"ACC-100{i}" for i in range(1, 7)])
        flagged_ids = {f.account_id for f in flags}
        for near_miss in ("ACC-2001", "ACC-2002", "ACC-3011", "ACC-3012", "ACC-3013"):
            self.assertNotIn(near_miss, flagged_ids)
        acc1004 = next(f for f in flags if f.account_id == "ACC-1004")
        self.assertNotIn("T1012", [t.txn_id for t in acc1004.windows[0].transactions])


if __name__ == "__main__":
    unittest.main()
